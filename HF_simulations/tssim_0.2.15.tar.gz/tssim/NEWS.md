tssim 0.2.0 to 0.2.7 (Release date: 2024-12-13)
============================================
Changes: - Added hs and mstl based simulation functions
         - Improved arguments and default setting for sim_daily

tssim 0.1.9 (Release date: 2024-05-10)
============================================
Changes: - Reintroduction and improvement of the change_sd parameter. It now more directly influences how quickly the seasonal component changes

tssim 0.1.8 (Release date: 2024-04-30)
============================================
Changes: - Improved the default setting of sim_daily and sim_monthly
	 - Restructured parts of the code of sim_sfac

tssim 0.1.6 (Release date: 2021-06-21)
============================================
Changes: - Updated documentation 
	 - Preparing cran release

tssim 0.1.5 (Release date: 2020-07-09)
============================================
Changes: - sim_sfac: Ensuring that the mean of all of the complete years (together) is 0 for additive and 1 for multiplicative seasonal factors

tssim 0.1.4 (Release date: 2020-07-09)
============================================
Changes: - Change of some defaults wrt to persistance (beta_1, beta_tau)

tssim 0.1.2 (Release date: 2020-06-30)
============================================
Changes: - Additional parameters or sim_daily()

tssim 0.1.0 (Release date: 2020-06-25)
============================================
First release of package